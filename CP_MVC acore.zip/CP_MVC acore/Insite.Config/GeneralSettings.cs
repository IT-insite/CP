﻿
// class that matches the appsetting.json params

namespace Insite.Configuration
{
    public class GeneralSettings
    {

        //Velocity Section
        public string VelocityApiHost { get; set; }
        public string VelocityProxyHost { get; set; }
        public string VelocityFactoryUsername { get; set; }
        public string VelocityFactoryPassword { get; set; }

        //Pay360
        public string Pay360ApiHost { get; set; }
        public string  Pay360Username { get; set; }
        public string Pay360Password { get; set; }
        public string Pay360ClientID { get; set; }
        public string Pay360InstallID { get; set; }

    }
}
