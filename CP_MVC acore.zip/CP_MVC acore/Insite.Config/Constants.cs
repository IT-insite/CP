﻿
// all insite constants here if dont want to put them in appsettings

namespace Insite.Configuration.Configuration
{
    public class Constants
    {


        public const int VelocityRetryDelay = 30000;
        public const int ReadyRetryDelay = 10000;
        public const int VelocityRetryNumber = 3;
        public const int TransactionsMonths = -3;

    }
}
