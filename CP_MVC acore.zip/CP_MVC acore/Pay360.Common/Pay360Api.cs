﻿using System;

namespace Pay360.Common
{
    public class Pay360Api
    {
    }
}
