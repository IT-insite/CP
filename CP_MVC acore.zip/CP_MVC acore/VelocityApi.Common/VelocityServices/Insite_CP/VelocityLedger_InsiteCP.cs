﻿using Insite.Configuration.Configuration;

using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.GTV.EBC.LEDGER.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityLedger_InsiteCP : IVelocityLedger_InsiteCP
    {
        private readonly EbcLedgerPortType _ebcLedgerPortType;


        public VelocityLedger_InsiteCP(EbcLedgerPortType ebcLedgerPortType)
        {
            _ebcLedgerPortType = ebcLedgerPortType;

        }

        public Task<List<EBCLEDGER_GETTRANSACTIONS_CALL_OUTPUTResultTransaction>> GetTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var transactionsRequest = new getTransactionsRequest
                    {
                        EBCLEDGER_GETTRANSACTIONS_CALL_INPUT = new EBCLEDGER_GETTRANSACTIONS_CALL_INPUT { classValue = accountNumber }
                    };
                    var transactionResult =  _ebcLedgerPortType.getTransactions(transactionsRequest).EBCLEDGER_GETTRANSACTIONS_CALL_OUTPUT.Result.Transactions.ToList();

                    foreach (var transaction in transactionResult)
                    {
                        if (transaction != null && !string.IsNullOrEmpty(transaction.amount))
                        {
                            var success = decimal.TryParse(transaction.amount, out decimal amount);

                            if (success)
                                transaction.amount = (-amount).ToString(); //amount is negated because in Velocity -'ve is a credit not a debt because it's velocity centric not customer centric
                        }
                    }

                    return transactionResult;
                }
                catch (FaultException fEx)
                {
                    //Installation wasn't found in Velocity
                    }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await GetTransactions(accountNumber, retry);
                    }
                 }
                return null;
            });
        }
    }
}
