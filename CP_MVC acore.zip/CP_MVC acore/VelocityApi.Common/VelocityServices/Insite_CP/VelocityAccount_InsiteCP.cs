﻿//using Insite.Configuration.Configuration;


using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.CCA.ACCOUNT.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityAccount_InsiteCP : IVelocityAccount_InsiteCP
    {
        private readonly AccountPortType _accountPortType;



        public VelocityAccount_InsiteCP(AccountPortType accountPortType)
        {
            _accountPortType = accountPortType;
         }

        public Task<ACCOUNT_BASIC_GET_OUTPUTResult> GetBasic(string accountNumber, int retry = 3)
        {
            return Task.Run(async () => {
                try
                {
                    var basicRequest = new getBasicRequest();
                    basicRequest.ACCOUNT_BASIC_GET_INPUT = new ACCOUNT_BASIC_GET_INPUT { classValue = accountNumber };
                    return _accountPortType.getBasic(basicRequest).ACCOUNT_BASIC_GET_OUTPUT.Result;
                } catch (FaultException fEx)
                {
                 } 
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetBasic(accountNumber, retry);
                    }
                }
                return null;
            });
        }
    }
}
