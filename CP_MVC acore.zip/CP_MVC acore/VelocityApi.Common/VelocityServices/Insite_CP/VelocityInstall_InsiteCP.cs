﻿using Insite.Configuration.Configuration;
using Microsoft.ApplicationInsights;
//using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.GTV.EBC.INSTALL.EDGE;
using webservices.gentrack.com.IIA_INSTALL.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityInstall_InsiteCP : IVelocityInstall_InsiteCP
    {
        private readonly InstallPortType _installPortType;
        private readonly EbcInstallPortType _ebcInstallPortType;
        //private readonly TelemetryClient _telemetryClient;

        public VelocityInstall_InsiteCP(EbcInstallPortType ebcInstallPortType, InstallPortType installPortType)//, TelemetryClient telemetryClient)
        {
            _installPortType = installPortType;
            _ebcInstallPortType = ebcInstallPortType;
            //_telemetryClient = telemetryClient;
        }

        public Task<INSTALL_BASIC_GET_OUTPUTResult> GetInstallBasic(string installation, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () => {
                try
                {
                    var basicRequest = new getBasicRequest();
                    basicRequest.INSTALL_BASIC_GET_INPUT = new INSTALL_BASIC_GET_INPUT { classValue = installation };
                    return _installPortType.getBasic(basicRequest).INSTALL_BASIC_GET_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                    //Installation wasn't found in Velocity
                    //_telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Description", "Installation not found in Velocity" }, { "Method", "getBasic" }, { "Installation", installation } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await GetInstallBasic(installation, retry);
                    }
                    //Some other error
                    //_telemetryClient.TrackException(ex, new Dictionary<string, string>() { { "Description", "Error communicating with Velocity" }, { "Method", "getBasic" }, { "Installation", installation }, { "Retry", retry.ToString()} });
                }
                return null;
            });
        }

        public Task<List<EBCINSTALL_GETMETERREGISTERS_CALL_OUTPUTResultInstallation>> GetMeterRegisters(string installation, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () => {
                try
                {
                    var registersRequest = new getMeterRegistersRequest();
                    registersRequest.EBCINSTALL_GETMETERREGISTERS_CALL_INPUT = new EBCINSTALL_GETMETERREGISTERS_CALL_INPUT { classValue = installation };
                    return _ebcInstallPortType.getMeterRegisters(registersRequest).EBCINSTALL_GETMETERREGISTERS_CALL_OUTPUT.Result.Installations.ToList();
                } catch (FaultException fEx)
                {
                    //Installation wasn't found in Velocity
                    //_telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Description", "Installation not found in Velocity" }, { "Installation", installation } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await GetMeterRegisters(installation, retry);
                    }
                    //Some other error
                    //_telemetryClient.TrackException(ex, new Dictionary<string, string>() { { "Description", "Error communicating with Velocity" }, { "Installation", installation }, { "Retry", retry.ToString() } });
                }
                return new List<EBCINSTALL_GETMETERREGISTERS_CALL_OUTPUTResultInstallation>();
            });
        }

        public Task<bool> LoadMeterReadings(List<EBCINSTALL_LOADMETERREADINGS_CALL_INPUTContentInstallation> loadRegisterList, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                var loadMeterReadingsRequest = new loadMeterReadingsRequest();
                loadMeterReadingsRequest.EBCINSTALL_LOADMETERREADINGS_CALL_INPUT = new EBCINSTALL_LOADMETERREADINGS_CALL_INPUT { Content = new EBCINSTALL_LOADMETERREADINGS_CALL_INPUTContent { Installations = loadRegisterList.ToArray() } };
                try
                {
                    var registersResult = _ebcInstallPortType.loadMeterReadings(loadMeterReadingsRequest);
                }
                catch (FaultException fEx)
                {
                    //_telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Description", "Can't send meter readings to Velocity" } });
                    throw fEx;
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await LoadMeterReadings(loadRegisterList, retry);
                    }
                    //Some other error
                    //_telemetryClient.TrackException(ex, new Dictionary<string, string>() { { "Description", "Error communicating with Velocity" }, { "Retry", retry.ToString() }, { "loadRegisterList", JsonSerializer.Serialize(loadRegisterList) } });
                    throw ex;
                }
                return true;
            });
        }
    }
}
