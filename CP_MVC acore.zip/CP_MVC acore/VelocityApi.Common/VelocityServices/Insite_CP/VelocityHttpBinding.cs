﻿using Insite.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.ServiceModel;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityHttpsBinding
    {
        /// <summary>
        /// Create Basic Https Binding for use in SOAP calls
        /// </summary>
        /// <param name="velocityConfiguration"></param>
        public VelocityHttpsBinding(IOptions<GeneralSettings> velocityConfiguration)
        {
            var binding = new BasicHttpsBinding();
            binding.SendTimeout = TimeSpan.FromSeconds(120);  //default 60 secs
            binding.OpenTimeout = TimeSpan.FromSeconds(120);  //default 60 secs
            binding.ReceiveTimeout = TimeSpan.FromSeconds(120);  //default 10 secs
            binding.CloseTimeout = TimeSpan.FromSeconds(120);
            binding.Security.Mode = BasicHttpsSecurityMode.Transport;  //Transport, None, TransportCredentialOnly
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            binding.MaxReceivedMessageSize = Int32.MaxValue;
            binding.MaxBufferSize = Int32.MaxValue;

            //Fiddler Proxy for inspecting SOAP messages
            if (!string.IsNullOrEmpty(velocityConfiguration.Value.VelocityProxyHost))
            {
                binding.ProxyAddress = new Uri(velocityConfiguration.Value.VelocityProxyHost);
                binding.UseDefaultWebProxy = false;
            }

            Binding = binding;
        }

        public BasicHttpsBinding Binding { get; }
    }

    public class VelocityHttpBinding
    {
        /// <summary>
        /// Create Basic Http Binding for use in SOAP calls
        /// </summary>
        /// <param name="velocityConfiguration"></param>
        public VelocityHttpBinding(IOptions<GeneralSettings> velocityConfiguration)
        {
            var binding = new BasicHttpBinding();
            binding.SendTimeout = TimeSpan.FromSeconds(120);  //default 60 secs
            binding.OpenTimeout = TimeSpan.FromSeconds(120);  //default 60 secs
            binding.ReceiveTimeout = TimeSpan.FromSeconds(20);  //default 10 secs
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;  //Transport, None, TransportCredentialOnly
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            binding.MaxReceivedMessageSize = Int32.MaxValue;
            binding.MaxBufferSize = Int32.MaxValue;

            //Fiddler Proxy for inspecting SOAP messages
            if (!string.IsNullOrEmpty(velocityConfiguration.Value.VelocityProxyHost))
            {
                binding.ProxyAddress = new Uri(velocityConfiguration.Value.VelocityProxyHost);
                binding.UseDefaultWebProxy = false;
            }

            Binding = binding;
        }

        public BasicHttpBinding Binding { get; }
    }
}
