﻿

using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.INSS.ACCOUNT.HELPER.EDGE;
using Insite.Configuration.Configuration;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityAccountHelper_InsiteCP : IVelocityAccountHelper_InsiteCP
    {
        private readonly AccountHelperPortType _accountHelperPortType;


        public VelocityAccountHelper_InsiteCP(AccountHelperPortType accountHelperPortType)//, TelemetryClient telemetryClient)
        {
            _accountHelperPortType = accountHelperPortType;

        }

        public Task<decimal?> GetThreshold(string accountNumber, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getThresholdRequest = new getThresholdRequest
                    {
                        ACCOUNTHELPER_GETTHRESHOLD_CALL_INPUT = new ACCOUNTHELPER_GETTHRESHOLD_CALL_INPUT { Content = new ACCOUNTHELPER_GETTHRESHOLD_CALL_INPUTContent { account = accountNumber } }
                    };
                    var getRatesResponse = _accountHelperPortType.getThreshold(getThresholdRequest);

                    var thresholdResponse = getRatesResponse.ACCOUNTHELPER_GETTHRESHOLD_CALL_OUTPUT.Result.threshold;

                    var success = decimal.TryParse(thresholdResponse, out decimal threshold);

                    if (!success)
                        return null;

                    return (decimal?)-threshold; //threshold is negated because in Velocity -'ve is a credit not a debt because it's velocity centric not customer centric

                }
                catch (FaultException fEx)
                {
                    return 0m; //API return an error "No Threshold set against scheme or account"
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetThreshold(accountNumber, retry);
                    }
                    return null;
                }
            });
        }

        public Task<List<ACCOUNTHELPER_GETASSETINSTALLATION_CALL_OUTPUTResultInstallations>> GetAssetInstallation(string accountNumber, string assetType, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getAssetInstallationRequest = new getAssetinstallationRequest
                    {
                        ACCOUNTHELPER_GETASSETINSTALLATION_CALL_INPUT = new ACCOUNTHELPER_GETASSETINSTALLATION_CALL_INPUT { Content = new ACCOUNTHELPER_GETASSETINSTALLATION_CALL_INPUTContent { account = accountNumber, assetType = assetType } }
                    };
                    var getAssetInstallationResponse = _accountHelperPortType.getAssetinstallation(getAssetInstallationRequest);

                    return getAssetInstallationResponse.ACCOUNTHELPER_GETASSETINSTALLATION_CALL_OUTPUT.Result.InstallationAssetDetails.ToList();
                }
                catch (FaultException fEx)
                {
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetAssetInstallation(accountNumber, assetType, retry);
                    }
                }
                return null;
            });
        }

        public Task<ACCOUNTHELPER_GETLASTTRANSACTION_CALL_OUTPUTResult> GetLastTransaction(string accountNumber, string transactionType, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getLastTransactionRequest = new getLastTransactionRequest
                    {
                        ACCOUNTHELPER_GETLASTTRANSACTION_CALL_INPUT = new ACCOUNTHELPER_GETLASTTRANSACTION_CALL_INPUT { Content = new ACCOUNTHELPER_GETLASTTRANSACTION_CALL_INPUTContent { account = accountNumber, transactionType = transactionType } }
                    };
                    var getLastTransationResponse = _accountHelperPortType.getLastTransaction(getLastTransactionRequest);

                    return getLastTransationResponse.ACCOUNTHELPER_GETLASTTRANSACTION_CALL_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetLastTransaction(accountNumber, transactionType, retry);
                    }
                }
                return null;
            });
        }

        public Task<decimal?> GetEmergencyCreditAllowance(string accountNumber, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getEmergencyCreditRequest = new getEmergencyCreditRequest
                    {
                        ACCOUNTHELPER_GETEMERGENCYCREDIT_CALL_INPUT = new ACCOUNTHELPER_GETEMERGENCYCREDIT_CALL_INPUT { Content = new ACCOUNTHELPER_GETEMERGENCYCREDIT_CALL_INPUTContent { account = accountNumber } }
                    };
                    var getEmergencyCreditResponse = _accountHelperPortType.getEmergencyCredit(getEmergencyCreditRequest);

                    var emergencyCreitResponse =  getEmergencyCreditResponse.ACCOUNTHELPER_GETEMERGENCYCREDIT_CALL_OUTPUT.Result.EmergencyCreditDetails.FirstOrDefault()?.emergencyCredit; //Not sure why this returns an array of emergencyCrredits?

                    if (string.IsNullOrEmpty(emergencyCreitResponse))
                        return 0m;

                    var success = decimal.TryParse(emergencyCreitResponse, out decimal emergencyCreditAllowance);

                    if (!success)
                        return null;

                    return (decimal?)emergencyCreditAllowance;
                }
                catch (FaultException fEx)
                {
                    return 0m; //API return an error "No Emergency Credit Allowance set against scheme or account"
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetEmergencyCreditAllowance(accountNumber, retry);
                    }
                    return null;
                }
            });
        }

        public Task SetEmergencyCreditStatus(string accountNumber, bool emergencyCreditActive, bool emergencyCreditDepleted, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var setEmergencyCreditStatusRequest = new setEmergencyCreditStatusRequest
                    {
                        ACCOUNTHELPER_SETEMERGENCYCREDITSTATUS_CALL_INPUT = new ACCOUNTHELPER_SETEMERGENCYCREDITSTATUS_CALL_INPUT { Content = new ACCOUNTHELPER_SETEMERGENCYCREDITSTATUS_CALL_INPUTContent { account = accountNumber, emergencyCreditActive = emergencyCreditActive, emergencyCreditDepleted = emergencyCreditDepleted, emergencyCreditActiveSpecified = true, emergencyCreditDepletedSpecified = true } }
                    };
                    var setEmergencyCreditStatsusResponse = _accountHelperPortType.setEmergencyCreditStatus(setEmergencyCreditStatusRequest); //This is fire and forget it's not going to affect any processing in Insite
                }
                catch (FaultException fEx)
                {
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        await SetEmergencyCreditStatus(accountNumber, emergencyCreditActive, emergencyCreditDepleted, retry);
                    }
                }
            });
        }

        private Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetAllTransactions(string accountNumber, JaaTransTypeClass ? transType, int retry = 3)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var transactionsRequest = new getTransactionsRequest
                    {
                        ACCOUNTHELPER_GETTRANSACTIONS_CALL_INPUT = new ACCOUNTHELPER_GETTRANSACTIONS_CALL_INPUT
                        {
                            Content = new ACCOUNTHELPER_GETTRANSACTIONS_CALL_INPUTContent { account = accountNumber, fromDateSpecified = true, fromDate = DateTime.UtcNow.AddMonths(Constants.TransactionsMonths) }
                        }
                    };
                    if (transType != null)
                    {
                        transactionsRequest.ACCOUNTHELPER_GETTRANSACTIONS_CALL_INPUT.Content.transactionTypeSpecified = true;
                        transactionsRequest.ACCOUNTHELPER_GETTRANSACTIONS_CALL_INPUT.Content.transactionType = (JaaTransTypeClass)transType;
                    }

                    //We only need credits to the account (Payments the customer has made), these are perversly -'ve.  This is because Velocity can't supply us the required API call so we have had to adapt to what they can provide.
                    var transactionResult = _accountHelperPortType.getTransactions(transactionsRequest).ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUT.Result.Transaction.ToList();

                    foreach (var transaction in transactionResult)
                    {
                        if (transaction != null && !string.IsNullOrEmpty(transaction.amount))
                        {
                            var success = decimal.TryParse(transaction.amount, out decimal amount);

                            if (success)
                                transaction.amount = (-amount).ToString(); //amount is negated because in Velocity -'ve is a credit not a debt because it's velocity centric not customer centric
                        }
                    }

                    return transactionResult;
                }
                catch (FaultException fEx)
                {
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(3000);
                        return await GetAllTransactions(accountNumber, transType, retry);
                    }
                }
                return new List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>(); //Empty List
            });
        }

        public Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetAllTransactions(string accountNumber, int retry = 3)
        {
            return GetAllTransactions(accountNumber, null);  //Payment transactions will be positive
        }

        public Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetStatementTransactions(string accountNumber, int retry = 3)
        {
            return GetAllTransactions(accountNumber, JaaTransTypeClass.STMNT);  //Payment transactions will be positive
        }

        public Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetInvoiceTransactions(string accountNumber, int retry = 3)
        {
            return GetAllTransactions(accountNumber, JaaTransTypeClass.INVC);  //Statement transactions will be negative
        }

        public Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetTransTransactions(string accountNumber, int retry = 3)
        {
            return GetAllTransactions(accountNumber, JaaTransTypeClass.TRANS);  //Statement transactions will be negative
        }
    }
}
