﻿using Insite.Configuration.Configuration;
//using Insite.TS.DataModels;
//using Insite.TS.Repositories.Interfaces;
using Microsoft.ApplicationInsights;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.CCD.CUSTOMER.EDGE;
using webservices.gentrack.com.GTV.EBC.CUSTOMER.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies
{
    public class VelocityCustomer_InsiteCP : IVelocityCustomer_InsiteCP
    {
        private readonly CustomerPortType _customerPortType;
        private readonly EbcCustomerPortType _ebcCustomerPortType;
       // private readonly TelemetryClient _telemetryClient;
       // private readonly IAccountEventLogRepository _accountEventLogRepository;

        public VelocityCustomer_InsiteCP(CustomerPortType customerPortType, EbcCustomerPortType ebcCustomerPortType) //, TelemetryClient telemetryClient, IAccountEventLogRepository accountEventLogRepository)
        {
            _customerPortType = customerPortType;
            _ebcCustomerPortType = ebcCustomerPortType;
           //_telemetryClient = telemetryClient;
           // _accountEventLogRepository = accountEventLogRepository;
        }

        public Task<CUSTOMER_BASIC_GET_OUTPUTResult> GetBasic(string customerNumber, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getBasicRequest = new getBasicRequest
                    {
                        CUSTOMER_BASIC_GET_INPUT = new CUSTOMER_BASIC_GET_INPUT { classValue = customerNumber }
                    };
                    return _customerPortType.getBasic(getBasicRequest).CUSTOMER_BASIC_GET_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                   // _telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Customer Number", customerNumber } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await GetBasic(customerNumber, retry);
                    }
                   // _telemetryClient.TrackException(ex, new Dictionary<string, string> { { "Description", "Error communicating with Velocity" }, { "Customer Number", customerNumber } });
                }
                return null;
            });
        }

        public Task<CUSTOMER_GETRELATIONSHIP_GET_OUTPUTResult> GetRelationship(string customerNumber, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var getRelationshipRequest = new getGetRelationshipRequest
                    {
                        CUSTOMER_GETRELATIONSHIP_GET_INPUT = new CUSTOMER_GETRELATIONSHIP_GET_INPUT { classValue = customerNumber }
                    };
                    return _customerPortType.getGetRelationship(getRelationshipRequest).CUSTOMER_GETRELATIONSHIP_GET_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                   // _telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Customer Number", customerNumber } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await GetRelationship(customerNumber, retry);
                    }
                   // _telemetryClient.TrackException(ex, new Dictionary<string, string> { { "Description", "Error communicating with Velocity" }, { "Customer Number", customerNumber } });
                }
                return null;
            });
        }

        public Task<EBCCUSTOMER_CUSTOMERLOGIN_CALL_OUTPUTResult> CustomerLogin(string customerNumber, int retry = Constants.VelocityRetryNumber) 
        {
            return Task.Run(async () =>
            {
                try
                {
                    var customerLoginRequest = new customerLoginRequest
                    {
                        EBCCUSTOMER_CUSTOMERLOGIN_CALL_INPUT = new EBCCUSTOMER_CUSTOMERLOGIN_CALL_INPUT { classValue = customerNumber }
                    };
                    return _ebcCustomerPortType.customerLogin(customerLoginRequest).EBCCUSTOMER_CUSTOMERLOGIN_CALL_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                   // _telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Customer Number", customerNumber } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await CustomerLogin(customerNumber, retry);
                    }
                  //  _telemetryClient.TrackException(ex, new Dictionary<string, string> { { "Description", "Error communicating with Velocity" }, { "Customer Number", customerNumber } });
                }
                return null;
            });
        }

        public Task<EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUTResult> AccountInstalls(string accountNumber, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var accountInstallsRequest = new getAccountInstallsRequest
                    {
                         EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_INPUT = new EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_INPUT { Content = new EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_INPUTContent { Filter = new EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_INPUTContentFilter { accountNumber = accountNumber } } }
                    };
                    return _ebcCustomerPortType.getAccountInstalls(accountInstallsRequest).EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                  //  _telemetryClient.TrackTrace("Velocity Fault Exception", new Dictionary<string, string> { { "FaultException Message", fEx.Message }, { "Account Number", accountNumber } });
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await AccountInstalls(accountNumber, retry);
                    }
                    //_telemetryClient.TrackException(ex, new Dictionary<string, string> { { "Description", "Error communicating with Velocity" }, { "Accoount Number", accountNumber } });
                    //_accountEventLogRepository.InsertEventLog(null, accountNumber, null, EventTypeEnum.Velocity, "EbcCustomer:GetAccountInstalls", EventOutcomeEnum.Failed, DescriptionEnum.VelocityFailedToReturnValidResponse, ex.Message);
                }
                return null;
            });
        }

        public Task<EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUTResult> AccountCustomers
            (string accountNumber, int retry = Constants.VelocityRetryNumber)
        {
            return Task.Run(async () =>
            {
                try
                {
                    var accountCustomersRequest = new getAccountCustomersRequest
                    {
                        EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_INPUT = new EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_INPUT { Content = new EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_INPUTContent { Filter = new EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_INPUTContentFilter { accountNumber = accountNumber } } }
                    };
                    return _ebcCustomerPortType.getAccountCustomers(accountCustomersRequest).EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUT.Result;
                }
                catch (FaultException fEx)
                {
                }
                catch (Exception ex)
                {
                    if (--retry > 0)
                    {
                        await Task.Delay(Constants.VelocityRetryDelay);
                        return await AccountCustomers(accountNumber, retry);
                    }
                }
                return null;
            });
        }
    }
}
