﻿using Insite.Configuration.Configuration;
using System.Threading.Tasks;
using webservices.gentrack.com.CCD.CUSTOMER.EDGE;
using webservices.gentrack.com.GTV.EBC.CUSTOMER.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityCustomer_InsiteCP
    {
        Task<CUSTOMER_BASIC_GET_OUTPUTResult> GetBasic(string customerNumber, int retry = Constants.VelocityRetryNumber);
        Task<CUSTOMER_GETRELATIONSHIP_GET_OUTPUTResult> GetRelationship(string customerNumber, int retry = Constants.VelocityRetryNumber);
        Task<EBCCUSTOMER_CUSTOMERLOGIN_CALL_OUTPUTResult> CustomerLogin(string customerNumber, int retry = Constants.VelocityRetryNumber);
        Task<EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUTResult> AccountInstalls(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUTResult> AccountCustomers(string accountNumber, int retry = Constants.VelocityRetryNumber);

    }
}
