﻿//using Insite.Configuration.Configuration;
using System.Collections.Generic;
using System.Threading.Tasks;
using webservices.gentrack.com.INSS.ACCOUNT.HELPER.EDGE;
using Insite.Configuration.Configuration;
namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityAccountHelper_InsiteCP
    {
        Task<decimal?> GetThreshold(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<decimal?> GetEmergencyCreditAllowance(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<List<ACCOUNTHELPER_GETASSETINSTALLATION_CALL_OUTPUTResultInstallations>> GetAssetInstallation(string accountNumber, string assetType, int retry = Constants.VelocityRetryNumber);
        Task<ACCOUNTHELPER_GETLASTTRANSACTION_CALL_OUTPUTResult> GetLastTransaction(string accountNumber, string transactionType, int retry = Constants.VelocityRetryNumber);
        Task SetEmergencyCreditStatus(string accountNumber, bool emergencyCreditActive, bool emergencyCreditDepleted, int retry = Constants.VelocityRetryNumber);
        Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetAllTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetStatementTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetInvoiceTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber);
        Task<List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions>> GetTransTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber);
    }
}
