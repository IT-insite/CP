﻿using Insite.Configuration.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using webservices.gentrack.com.GTV.EBC.INSTALL.EDGE;
using webservices.gentrack.com.IIA_INSTALL.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityInstall_InsiteCP
    {
        Task<INSTALL_BASIC_GET_OUTPUTResult> GetInstallBasic(string installation, int retry = Constants.VelocityRetryNumber);
        Task<List<EBCINSTALL_GETMETERREGISTERS_CALL_OUTPUTResultInstallation>> GetMeterRegisters(string installation, int retry = Constants.VelocityRetryNumber);
        Task<bool> LoadMeterReadings(List<EBCINSTALL_LOADMETERREADINGS_CALL_INPUTContentInstallation> loadRegisterList, int retry = Constants.VelocityRetryNumber);
    }
}
