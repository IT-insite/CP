﻿using Insite.Configuration.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using webservices.gentrack.com.GTV.EBC.LEDGER.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityLedger_InsiteCP
    {
        
        Task<List<EBCLEDGER_GETTRANSACTIONS_CALL_OUTPUTResultTransaction>> GetTransactions(string accountNumber, int retry = Constants.VelocityRetryNumber);
    }
}
