﻿using Insite.Configuration.Configuration;
using System.Collections.Generic;
using System.Threading.Tasks;
using webservices.gentrack.com.INSS.CONSUMER.HELPER.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityConsumerHelper_InsiteCP
    {
        Task<List<CONSUMERHELPER_GETRATES_CALL_OUTPUTResultRate>> GetRates(string consumerNumber, int retry = Constants.VelocityRetryNumber);
        Task<List<CONSUMERHELPER_GETSTANDINGCHARGES_CALL_OUTPUTResultStandingCharge>> GetStandingCharges(string consumerNumber, int retry = Constants.VelocityRetryNumber);
        Task<CONSUMERHELPER_GETPREPAYDEBTSCHEDULE_CALL_OUTPUTResult> GetPrepayDebtSchedule(string consumerNumber, bool defaultToCompleted, int retry = Constants.VelocityRetryNumber);
    }
}
