﻿using Insite.Configuration.Configuration;
using System;
using System.Threading.Tasks;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityCustomerHelper_InsiteCP
    {
        Task<bool> SendPassswordResetEmail(string customerNumber, Uri uri, int retry = Constants.VelocityRetryNumber);
        Task<bool> SendWelcomeEmail(string customerNumber, Uri uri, int retry = Constants.VelocityRetryNumber);
        Task<string> CustomerGetUrlMethodIns(string customerNumber, int retry = Constants.VelocityRetryNumber);
        Task<bool> CustomerActivationConfirm(string customerNumber, Uri uri, int retry = Constants.VelocityRetryNumber);
    }
}
