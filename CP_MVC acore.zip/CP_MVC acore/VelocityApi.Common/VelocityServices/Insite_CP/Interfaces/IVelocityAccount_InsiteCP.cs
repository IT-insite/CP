﻿using Insite.Configuration.Configuration;
using System.Threading.Tasks;
using webservices.gentrack.com.CCA.ACCOUNT.EDGE;

namespace VelocityApi.Common.VelocityServices.Proxies.Interfaces
{
    public interface IVelocityAccount_InsiteCP
    {
        Task<ACCOUNT_BASIC_GET_OUTPUTResult> GetBasic(string accountNumber, int retry = Constants.VelocityRetryNumber);
    }
}
