using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



using VelocityApi.Common.VelocityServices.Proxies;
using VelocityApi.Common.VelocityServices.Proxies.Interfaces;

using webservices.gentrack.com.GTV.EBC.CUSTOMER.EDGE;
using webservices.gentrack.com.GTV.EBC.INSTALL.EDGE;
using webservices.gentrack.com.GTV.EBC.LEDGER.EDGE;
using webservices.gentrack.com.INSS.ACCOUNT.HELPER.EDGE;
using webservices.gentrack.com.INSS.CONSUMER.HELPER.EDGE;
using webservices.gentrack.com.LAM.METER.EDGE;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using webservices.gentrack.com.INSS.METER.HELPER.EDGE;

using webservices.gentrack.com.INSS.TRANSACTION.HELPER.EDGE;
using webservices.gentrack.com.GTV.JBI.LEDGER.EDGE;
using webservices.gentrack.com.CCA.CUSTOMER.BRAND.EDGE;
using webservices.gentrack.com.CCA.ACCOUNT.EDGE;
using webservices.gentrack.com.CCD.CUSTOMER.ROLE.TYPE.EDGE;
using webservices.gentrack.com.CCD.CUSTOMER.ROLE.EDGE;
using webservices.gentrack.com.IIA_INSTALL.EDGE;
using webservices.gentrack.com.LAA_ASSET.EDGE;
using webservices.gentrack.com.INSS.CUSTOMER.HELPER.EDGE;
using webservices.gentrack.com.CCD.CUSTOMER.EDGE;
using Insite.Common.Extensions;
using Insite.Configuration;
using System.ServiceModel.Channels;

namespace CP_MVC
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();

            services.Configure<GeneralSettings>(Configuration);

            //HTTP bindings for velocity
            if (Configuration.GetValue<string>("VelocityApiHost").ToLowerInvariant().StartsWith("https"))
                services.AddSingleton<VelocityHttpsBinding>();
            else
                services.AddSingleton<VelocityHttpBinding>();


            services.AddSingleton(AddressHeader.CreateAddressHeader("s:OnBehalfOf type=\"xs:normalizedString\" id=\"xs:normalizedString\"", "http://webservices.gentrack.com/", ""));  //https://stackoverflow.com/questions/964433/how-to-add-a-custom-http-header-to-every-wcf-call
            services.AddSingleton(x => new AddressHeader[1] { x.GetRequiredService<AddressHeader>() });


            //create Velocity SOAP instances 

            services.AddVelocityService<EbcCustomerPortType>("MOD/WEBSERVICES/GTV:EBC.CUSTOMER?version=2&edition=5");
            services.AddVelocityService<EbcInstallPortType>("MOD/WEBSERVICES/GTV:EBC.INSTALL?version=2&edition=5");
            services.AddVelocityService<EbcLedgerPortType>("MOD/WEBSERVICES/GTV:EBC.LEDGER?version=2&edition=5");
            services.AddVelocityService<AccountHelperPortType>("MOD/WEBSERVICES/INSS:ACCOUNT.HELPER?version=1&edition=5");
            services.AddVelocityService<ConsumerHelperPortType>("MOD/WEBSERVICES/INSS:CONSUMER.HELPER?version=1&edition=5");
            services.AddVelocityService<MeterPortType>("MOD/WEBSERVICES/LAM:METER?version=2&edition=5");
            services.AddVelocityService<MeterHelperPortType>("MOD/WEBSERVICES/INSS:METER.HELPER?version=1&edition=5");
            services.AddVelocityService<TransactionHelperPortType>("MOD/WEBSERVICES/INSS:TRANSACTION.HELPER?version=1&edition=5");
            services.AddVelocityService<LedgerPortType>("MOD/WEBSERVICES/JBI:LEDGER?version=1&edition=5");
            services.AddVelocityService<CustomerBrandPortType>("MOD/WEBSERVICES/CCA:CUSTOMER.BRAND?version=1&edition=5");
            services.AddVelocityService<AccountPortType>("MOD/WEBSERVICES/CCA:ACCOUNT?version=4&edition=5");
            services.AddVelocityService<CustomerRoleTypePortType>("MOD/WEBSERVICES/CCD:CUSTOMER.ROLE.TYPE?version=1&edition=5");
            services.AddVelocityService<CustomerRolePortType>("MOD/WEBSERVICES/CCD:CUSTOMER.ROLE?version=1&edition=5");
            services.AddVelocityService<InstallPortType>("MOD/WEBSERVICES/IIA:INSTALL?version=2&edition=5");
            services.AddVelocityService<AssetPortType>("MOD/WEBSERVICES/LAA:ASSET?version=1&edition=5");
            services.AddVelocityService<CustomerHelperPortType>("MOD/WEBSERVICES/INSS:CUSTOMER.HELPER?version=1&edition=5");
            services.AddVelocityService<CustomerPortType>("MOD/WEBSERVICES/CCD:CUSTOMER?version=2&edition=5");

            
            
            // create class objects instances for the interface in velocity.common module


            services.AddScoped<IVelocityAccountHelper_InsiteCP, VelocityAccountHelper_InsiteCP>();
            services.AddScoped<IVelocityAccount_InsiteCP, VelocityAccount_InsiteCP>();
            services.AddScoped<IVelocityInstall_InsiteCP, VelocityInstall_InsiteCP>();
            services.AddScoped<IVelocityCustomer_InsiteCP, VelocityCustomer_InsiteCP>();
            services.AddScoped<IVelocityLedger_InsiteCP, VelocityLedger_InsiteCP>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.

        // this is created by MVC
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
