﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webservices.gentrack.com.CCA.ACCOUNT.EDGE;
using webservices.gentrack.com.CCD.CUSTOMER.EDGE;
using webservices.gentrack.com.GTV.EBC.CUSTOMER.EDGE;
using webservices.gentrack.com.IIA_INSTALL.EDGE;
using webservices.gentrack.com.INSS.ACCOUNT.HELPER.EDGE;


namespace CP_MVC.Models
{
    public class ContactViewModel
    {
        ACCOUNT_BASIC_GET_OUTPUTResult accountdata;
        EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUTResult customerdata;
        EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUTResult installdata;
        INSTALL_BASIC_GET_OUTPUTResult installdetails;

        decimal? emergencycredit;
        List <ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsdata;
        List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsInvoice;
        List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsPay;

        string accountid;
        public ContactViewModel(string accountid
            , ACCOUNT_BASIC_GET_OUTPUTResult accountdata
            , EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUTResult customerdata
            , EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUTResult installdata
            , INSTALL_BASIC_GET_OUTPUTResult installdetails


            , decimal? emergencycredit
            , List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsdata 
            , List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsInvoice
            , List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> transactionsPay)
        {
            this.accountdata = accountdata;
            this.customerdata = customerdata;
            this.installdata = installdata;
            this.installdetails = installdetails;
            this.emergencycredit = emergencycredit;
            this.transactionsdata = transactionsdata;
            this.transactionsInvoice = transactionsInvoice;
            this.transactionsPay = transactionsPay;
            this.accountid = accountid;
        }

        public ACCOUNT_BASIC_GET_OUTPUTResult AccountData { get { return accountdata; } }

        public EBCCUSTOMER_GETACCOUNTCUSTOMERS_CALL_OUTPUTResult CustomerData { get { return customerdata; } }

        public EBCCUSTOMER_GETACCOUNTINSTALLS_CALL_OUTPUTResult InstallData { get { return installdata; } }

        public INSTALL_BASIC_GET_OUTPUTResult InstallDetails { get { return installdetails; } }
        public decimal ? EmergencyCredit { get { return emergencycredit; } }


        public List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> TransactionsData { get { return transactionsdata; } }
        public List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> TransactionsInvoice { get { return transactionsInvoice; } }
        public List<ACCOUNTHELPER_GETTRANSACTIONS_CALL_OUTPUTResultTransactions> TransactionsPay { get { return transactionsPay; } }

        public string? AccountID { get { return accountid; } }

    }
}
