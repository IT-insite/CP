﻿using CP_MVC.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using VelocityRepository.Repository.Interfaces;

using VelocityApi.Common.VelocityServices.Proxies.Interfaces;
using webservices.gentrack.com.IIA_INSTALL.EDGE;

namespace CP_MVC.Controllers
{
    public class InsiteTestController : Controller
    {
        private readonly IVelocityAccount_InsiteCP _velocityAccount;
        private readonly IVelocityAccountHelper_InsiteCP _velocityAccountHelper;
        private readonly IVelocityInstall_InsiteCP _velocityInstall;
        private readonly IVelocityCustomer_InsiteCP _velocityCustomer;


        // constructor to link to startup
        public InsiteTestController(IVelocityAccount_InsiteCP velocityAccount
            , IVelocityAccountHelper_InsiteCP velocityAccountHelper
            , IVelocityInstall_InsiteCP velocityInstall
            , IVelocityCustomer_InsiteCP velocityCustomer)
        {
            _velocityAccount = velocityAccount;
            _velocityAccountHelper = velocityAccountHelper;
            _velocityInstall = velocityInstall;
            _velocityCustomer = velocityCustomer;
        }

        /*
        [HttpPost]
        public async Task<ActionResult> gtvAccountName(IFormCollection formdata)
        {
            var result = await _velocityAccount.GetBasic(accountNumber: formdata["AccountNumber"]);
            if (result == null)
                return BadRequest("Account dont exist"); //Content("Account doesnt exist");
            var vm = new ContactViewModel(result,null,null,null );
            return View(vm);

        }


        
        public async Task<ActionResult> gtvAccountName( string accountNumber)
        {
            var result = await _velocityAccount.GetBasic(accountNumber: accountNumber);
            if (result == null)
                return BadRequest("Account dont exist"); //Content("Account doesnt exist");
            var vm = new ContactViewModel(result,null,null);
            return View(vm); // Content("AccountName: " + result.AccountInformation.accountName + " postal name:" + result.AccountInformation.postalName);
        }

        
        public async Task<ActionResult> gtvAccountInstall(string accountNumber)
        {
            var result = await _velocityInstall.GetInstallBasic(accountNumber: accountNumber);
            if (result == null)
                return BadRequest("Account dont exist"); //Content("Account doesnt exist");
            var vm = new ContactViewModel(result, null);
            return View(vm); // Content("AccountName: " + result.AccountInformation.accountName + " postal name:" + result.AccountInformation.postalName);
        }



        public async Task<ActionResult> gtvAccountEmergencyAllowance(string accountNumber)
        {
            var result = await _velocityAccountHelper.GetEmergencyCreditAllowance(accountNumber: accountNumber);
            if (result == null)
                return Content("Account doesnt exist");
            return Content("Emergency credit allowance: " + result.Value.ToString());
        }

        */





        public async Task<ActionResult> gtvAccountdata(string accountNumber)
        {


            
            var instdetailresult = new INSTALL_BASIC_GET_OUTPUTResult();
           
            var accresult = await _velocityAccount.GetBasic(accountNumber: accountNumber); if (accresult == null)
                return BadRequest("no account info");

           
            var custresult = await _velocityCustomer.AccountCustomers(accountNumber: accountNumber); if (custresult == null)
                return BadRequest("no cust info");

           
            var instresult = await _velocityCustomer.AccountInstalls(accountNumber: accountNumber); 
            
            if (instresult == null)
                return BadRequest("no install info");
            else
                instdetailresult = await _velocityInstall.GetInstallBasic(installation: instresult.Account.Consumers[0].Installation.installation);


            var result1 = await _velocityAccountHelper.GetEmergencyCreditAllowance(accountNumber: accountNumber);
            if (result1 == null)
                return BadRequest("no Emergemcy credit"); //Content("Account doesnt exist");


            var result2 = await _velocityAccountHelper.GetAllTransactions(accountNumber: accountNumber);
            if (result2 == null)
                return BadRequest("no transactions"); //Content("Account doesnt exist");

            var result3 = await _velocityAccountHelper.GetInvoiceTransactions (accountNumber: accountNumber);
            if (result3 == null)
                return BadRequest("no transactions"); //Content("Account doesnt exist");

            var result4 = await _velocityAccountHelper.GetStatementTransactions (accountNumber: accountNumber);
            if (result4 == null)
                return BadRequest("no transactions"); //Content("Account doesnt exist");



            var vm = new ContactViewModel(accountNumber, accresult,custresult,  instresult, instdetailresult, result1,result2,result3,result4);
            return View(vm);
        }



        // GET: hello
        [HttpGet]
        public ActionResult Index()
        {

            return Content("no service at this location: " +
                "<test1> gtvAccountName?AccountNumber=12345678 " +
                "<test2> gtvAccountEmergencyAllowance?AccountNumber=12345678 " +
                "<test3> gtvAccountdata?AccountNumber = 12345678" );
        }

        [HttpGet]
        public ActionResult me()
        {
            return Content("hello Hacene from Insite");
        }

        
    }
}
