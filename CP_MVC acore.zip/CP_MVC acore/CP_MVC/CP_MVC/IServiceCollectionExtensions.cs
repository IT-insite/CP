﻿using Insite.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using VelocityApi.Common.VelocityServices.Proxies;

namespace Insite.Common.Extensions
{
    public static class IServiceCollectionExtensions
    {
        public static IServiceCollection AddVelocityService<T>(this IServiceCollection services, string endPointAddress) where T : class
        {
            services.AddSingleton(x => { //INSTALL end poont
                var serviceEndpoint = x.GetRequiredService<IOptions<GeneralSettings>>().Value.VelocityApiHost;
                Uri uri = new Uri($"{serviceEndpoint}{endPointAddress}");

                ChannelFactory<T> installFactory;
                if (serviceEndpoint.StartsWith("https"))
                    installFactory = new ChannelFactory<T>(x.GetRequiredService<VelocityHttpsBinding>().Binding, new EndpointAddress(uri, x.GetRequiredService<AddressHeader[]>()));
                else
                    installFactory = new ChannelFactory<T>(x.GetRequiredService<VelocityHttpBinding>().Binding, new EndpointAddress(uri, x.GetRequiredService<AddressHeader[]>()));

                installFactory.Credentials.UserName.UserName = x.GetRequiredService<IOptions<GeneralSettings>>().Value.VelocityFactoryUsername;
                installFactory.Credentials.UserName.Password = x.GetRequiredService<IOptions<GeneralSettings>>().Value.VelocityFactoryPassword;
                return installFactory.CreateChannel();
            });

            return services;
        }
    }
}
